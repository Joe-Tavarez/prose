# Run pilot2-qwen3-coder-30b

| Condition | Instance | Solution | Prep s | Baseline build | Roslyn load | Driver | Steps | Patch | Checks |
|---|---|---|---|---|---|---|---|---|---|
| text | autofac__autofac-1424 | Autofac.sln (SDK 8.0.401) | 1.8 | exit 0, 0 err, 13.0s |  | 0 | 78 | 37 | OK |
| roslyn | autofac__autofac-1424 | Autofac.sln (SDK 8.0.401) | 1.7 | exit 0, 0 err, 12.8s | 24 proj, 1 diag, 4.1s | 0 | 66 | 263 | OK |
| roslyn-enforced | autofac__autofac-1424 | Autofac.sln (SDK 8.0.401) | 2.4 | exit 0, 0 err, 8.0s | 24 proj, 1 diag, 5.1s | 0 | 74 | 334 | OK |
| text | serilog__serilog-2083 | Serilog.sln (SDK 8.0.100) | 1.7 | exit 0, 0 err, 4.1s |  | 0 | 15 | 13 | OK |
| roslyn | serilog__serilog-2083 | Serilog.sln (SDK 8.0.100) | 1.5 | exit 0, 0 err, 2.1s | 11 proj, 2 diag, 3.1s | 0 | 29 | 14 | OK |

Timed out (wall clock, safety net): 0
Invalid (Ollama truncated/cut or condenser check failed; not in predictions): 0
Largest prompt + reply seen by Ollama: 46488 of 65536
Interrupted and redone (e.g. PC restart): 0
