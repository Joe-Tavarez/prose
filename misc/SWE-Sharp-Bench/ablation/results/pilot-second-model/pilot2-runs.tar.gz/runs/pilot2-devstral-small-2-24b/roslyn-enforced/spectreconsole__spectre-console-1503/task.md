<uploaded_files>
/srv/ablation/work/spectreconsole__spectre.console
</uploaded_files>

I've uploaded a C# code repository in the directory /srv/ablation/work/spectreconsole__spectre.console. Consider the following issue description:

<issue_description>
Export for Documentation
I'm currently manually creating the documentation to put on my site for the CLI usage. Which gave me a thought...

Would it be possible to do some sort of export of the the documentation. 

If I have branch commands I have to go into each command and call `-h` to get the output for that command, then I use that to build the documentation on the site.

I have no idea how you would solve it nicely, maybe a nuget tool which analysis it and generates a .md file. 

Feel free to close this is my idea is stupid...
</issue_description>

Can you help me implement the necessary changes to the repository so that the requirements specified in the <issue_description> are met?
I've already taken care of all changes to any of the test files described in the <issue_description>. This means you DON'T have to modify the testing logic or any of the tests in any way!
Your task is to make the minimal changes to non-test files in the /srv/ablation/work/spectreconsole__spectre.console directory to ensure the <issue_description> is satisfied.
