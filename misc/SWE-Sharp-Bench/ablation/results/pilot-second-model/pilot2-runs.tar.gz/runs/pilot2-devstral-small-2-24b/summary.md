# Run pilot2-devstral-small-2-24b

| Condition | Instance | Solution | Prep s | Baseline build | Roslyn load | Driver | Steps | Patch | Checks |
|---|---|---|---|---|---|---|---|---|---|
| text | autofac__autofac-1424 | Autofac.sln (SDK 8.0.401) | 2.6 | exit 0, 0 err, 14.6s |  | 1 | 0 | 0 | OK |
| roslyn | autofac__autofac-1424 | Autofac.sln (SDK 8.0.401) | 1.7 | exit 0, 0 err, 8.3s | 24 proj, 1 diag, 5.1s | 1 | 0 | 0 | OK |
| roslyn-enforced | autofac__autofac-1424 | Autofac.sln (SDK 8.0.401) | 1.7 | exit 0, 0 err, 5.4s | 24 proj, 1 diag, 4.1s | 1 | 0 | 0 | OK |
| text | serilog__serilog-2083 | Serilog.sln (SDK 8.0.100) | 1.6 | exit 0, 0 err, 4.1s |  | 1 | 0 | 0 | OK |
| roslyn | serilog__serilog-2083 | Serilog.sln (SDK 8.0.100) | 1.4 | exit 0, 0 err, 3.1s | 11 proj, 2 diag, 3.1s | 1 | 0 | 0 | OK |
| roslyn-enforced | serilog__serilog-2083 | Serilog.sln (SDK 8.0.100) | 1.4 | exit 0, 0 err, 1.9s | 11 proj, 2 diag, 3.1s | 1 | 0 | 0 | OK |
| text | spectreconsole__spectre-console-1503 | src/Spectre.Console.sln (SDK 8.0.204) | 1.7 | exit 0, 0 err, 9.1s |  | 1 | 0 | 0 | OK |
| roslyn | spectreconsole__spectre-console-1503 | src/Spectre.Console.sln (SDK 8.0.204) | 1.5 | exit 0, 0 err, 7.2s | 24 proj, 0 diag, 4.1s | 1 | 0 | 0 | OK |
| roslyn-enforced | spectreconsole__spectre-console-1503 | src/Spectre.Console.sln (SDK 8.0.204) | 1.6 | exit 0, 0 err, 4.8s | 24 proj, 0 diag, 4.1s | 1 | 0 | 0 | OK |

Timed out (wall clock, safety net): 0
Invalid (Ollama truncated/cut or condenser check failed; not in predictions): 0
Interrupted and redone (e.g. PC restart): 0
