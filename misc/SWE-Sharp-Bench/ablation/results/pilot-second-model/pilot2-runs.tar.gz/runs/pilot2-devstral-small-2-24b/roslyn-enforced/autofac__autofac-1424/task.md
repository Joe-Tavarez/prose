<uploaded_files>
/srv/ablation/work/autofac__Autofac
</uploaded_files>

I've uploaded a C# code repository in the directory /srv/ablation/work/autofac__Autofac. Consider the following issue description:

<issue_description>
[Autofac 6.4.0]: RegisterGenericDecorator() resolves incorrect instance for the decorated type 
## Describe the Bug

When I register a generic decorator for my command handlers with `RegisterGenericDecorator()` and then try to resolve all command handlers by `container.Resolve(IEnumerable<IHandler<Command>>)`, the returned decorators all decorate the same instance.

## Steps to Reproduce

full code [here](https://github.com/ViktorDolezel/AutofacDecorators/blob/master/Program.cs)

```c#
[TestFixture]
public class ReproTest
{
   [Test]
   public void ResolveAllDecoratedCommandHandlers_IsSuccessful()
    {
        //Arrange
        var builder = new ContainerBuilder();

        builder.RegisterType(typeof(CommandHandler1))
            .As(typeof(ICommandHandler<Command>))
            .As(typeof(IHandler<Command>));
        builder.RegisterType(typeof(CommandHandler2))
            .As(typeof(ICommandHandler<Command>))
            .As(typeof(IHandler<Command>));

        builder.RegisterGenericDecorator(
            typeof(CommandHandlerDecorator<>),
            typeof(IHandler<>),
            context => context.ImplementationType.GetInterfaces().Any(t => t.IsGenericType 
                && t.GetGenericTypeDefinition() == typeof(ICommandHandler<>))
        );

        var container = builder.Build();

        //Act
        var commandHandlers = ((IEnumerable<IHandler<Command>>)container.Resolve(typeof(IEnumerable<IHandler<Command>>))).ToList();
        
        //Assert
        Assert.AreEqual(
            ((CommandHandlerDecorator<Command>)commandHandlers[0]).Decorated.GetType(), 
            typeof(CommandHandler1)); //fails, decorated is typeof(CommandHandler2)
        Assert.AreEqual(
            ((CommandHandlerDecorator<Command>)commandHandlers[1]).Decorated.GetType(), 
            typeof(CommandHandler2));

    }
}

interface IRequest { }
interface IHandler<in TRequest> where TRequest : IRequest { public void Handle(TRequest request); } 

interface ICommand: IRequest { }
interface ICommandHandler<in TCommand>: IHandler<TCommand> where TCommand: ICommand { } 

class Command : ICommand { }
class CommandHandler1 : ICommandHandler<Command> { public void Handle(Command command) => Console.WriteLine("CommandHandler1"); }
class CommandHandler2 : ICommandHandler<Command> { public void Handle(Command command) => Console.WriteLine("CommandHandler2"); }

class CommandHandlerDecorator<TCommand> : ICommandHandler<TCommand> where TCommand : ICommand
{
    public ICommandHandler<TCommand> Decorated { get; }
    public CommandHandlerDecorator(ICommandHandler<TCommand> decorated) => Decorated = decorated;
    public void Handle(TCommand request)
    {
        Console.WriteLine($"Command Decorator for {Decorated.GetType().FullName}");
        Decorated.Handle(request);
    }
}
```

## Expected Behavior

the above unit test should pass:

Without using decorators, `container.Resolve<IEnumerable<IHandler<Command>>()` returns expected `{ CommandHandler1, CommandHandler2 }`.
With decorators, I'm expecting `{ CommandHandlerDecorator(CommandHandler1), CommandHandlerDecorator(CommandHandler2) }` but getting `{ CommandHandlerDecorator(CommandHandler2), CommandHandlerDecorator(CommandHandler2) }`.

## Dependency Versions

Autofac: 6.4.0

## Additional Info

This was encountered with the MediatR library where MediatR works on its base interface `IRequest`. 
I have control over the registration part (the "Arrange" section in the unit test) but not how MediatR resolves the command handlers.
In other words, the following solutions would not solve my issue:
 - Resolve by calling `Resolve(typeof(IEnumerable<ICommandHandler<Command>>)` rather than `Resolve(typeof(IEnumerable<IHandler<Command>>)`   [_no control over that_]
 - Get rid of `ICommand` and `IQuery` [_but I needz them! for example, the `UnitOfWorkCommandHandlerDecorator` should only apply to CommandHandlers_]
 - ditch MediatR 
 - use `IPipelineBehavior` of MediatR instead [_the problem is present for `MediatR.INofitication`s as well and those don't support pipelines_]

(thank you for your time, you are appreciated!)
</issue_description>

Can you help me implement the necessary changes to the repository so that the requirements specified in the <issue_description> are met?
I've already taken care of all changes to any of the test files described in the <issue_description>. This means you DON'T have to modify the testing logic or any of the tests in any way!
Your task is to make the minimal changes to non-test files in the /srv/ablation/work/autofac__Autofac directory to ensure the <issue_description> is satisfied.
