<uploaded_files>
/srv/ablation/work/serilog__serilog
</uploaded_files>

I've uploaded a C# code repository in the directory /srv/ablation/work/serilog__serilog. Consider the following issue description:

<issue_description>
Consider using `Major.0.0.0` or `Major.Minor.0.0` assembly versioning
Since Serilog 4.0.0 uses an assembly version 4.0.0.0, we've still got some wiggle-room to tweak the assembly versioning policy. Because new features _do_ cause issues when assembly versions are mismatched, `Major.Minor.0.0` is the most general versioning scheme that is likely to work for us.

See also #2073 and https://learn.microsoft.com/en-us/dotnet/standard/library-guidance/versioning.
</issue_description>

Can you help me implement the necessary changes to the repository so that the requirements specified in the <issue_description> are met?
I've already taken care of all changes to any of the test files described in the <issue_description>. This means you DON'T have to modify the testing logic or any of the tests in any way!
Your task is to make the minimal changes to non-test files in the /srv/ablation/work/serilog__serilog directory to ensure the <issue_description> is satisfied.
